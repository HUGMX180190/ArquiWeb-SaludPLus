package pe.edu.sp.demosaludplus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSaludPlusApplicationTests {

    @Test
    void contextLoads() {
    }

}
