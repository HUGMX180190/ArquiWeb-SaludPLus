package pe.edu.sp.demosaludplus.servicesimplements;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.sp.demosaludplus.Entities.EducacionSalud;
import pe.edu.sp.demosaludplus.Repositories.IEducacionSaludRepository;
import pe.edu.sp.demosaludplus.servicesinterfaces.IEducacionSaludService;

import java.util.List;
@Service
public class EducacionSaludServiceImplement implements IEducacionSaludService {
    @Autowired
    private IEducacionSaludRepository repository;
    @Override
    public List<EducacionSalud> list() {
        return this.repository.findAll();
    }
    @Override
    public void insert(EducacionSalud educacionSalud) {
        this.repository.save(educacionSalud);
    }
}
