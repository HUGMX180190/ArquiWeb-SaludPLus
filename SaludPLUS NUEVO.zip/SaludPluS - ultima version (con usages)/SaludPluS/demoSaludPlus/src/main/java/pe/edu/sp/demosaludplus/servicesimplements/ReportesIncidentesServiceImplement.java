package pe.edu.sp.demosaludplus.servicesimplements;


import pe.edu.sp.demosaludplus.Entities.ReportesIncidentes;
import pe.edu.sp.demosaludplus.servicesinterfaces.IReportesIncidentesService;

import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ReportesIncidentesServiceImplement implements IReportesIncidentesService {


    @Override
    public List<ReportesIncidentes> list() {
        return List.of();
    }

    @Override
    public void insert(ReportesIncidentes reportesIncidentes) {

    }

    @Override
    public ReportesIncidentes list(int idReporte) {
        return null;
    }

    @Override
    public void delete(int idReporte) {

    }

    @Override
    public void update(ReportesIncidentes reportesIncidentes) {

    }

    @Override
    public List<ReportesIncidentes> buscarBigDataReportes(String nReportes) { //PREGUNTAR 
        return List.of();
    }


}


