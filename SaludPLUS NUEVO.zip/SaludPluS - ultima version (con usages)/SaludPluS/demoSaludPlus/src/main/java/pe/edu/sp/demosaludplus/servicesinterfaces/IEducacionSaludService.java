package pe.edu.sp.demosaludplus.servicesinterfaces;

import pe.edu.sp.demosaludplus.Entities.EducacionSalud;

import java.util.List;

public interface IEducacionSaludService {
    public List<EducacionSalud> list();
    public void insert(EducacionSalud educacionSalud);


}
